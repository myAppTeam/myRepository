# Parse JSON From Web & Populate UITableView in Swift using NSURLSession
Simple Swift iOS Application demonstrating NSURLSession and populating a UITableView with JSON.

This project is injunction with the article I wrote at <a href="medium.com/@farhansyed">Medium<a/> trying to help others understand the basics of grabbing JSON from a web API and to take the data recieved and populate a UITableView.

If you have any questions, feel free to let me know 😊

