import UIKit


public class destin {
    var destinName = ""
    var countryName = ""
    
    func destinDictionary(dict: NSDictionary) -> destin {
        // print("dict === \(dict)")
        self.destinName = (dict["name"] as! String)
        print(destinName)
        return self
    }
    
    
    
}
