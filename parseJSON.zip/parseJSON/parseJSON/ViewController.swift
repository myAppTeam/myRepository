//
//  ViewController.swift
//  parseJSON
//
//  Created by Farhan Syed on 4/9/17.
//  Copyright © 2017 Farhan Syed. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UITableViewController  {
    
    var tableArray = NSArray()
    let destinObj = destin()
    
    @IBOutlet var jsonTable: UITableView!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        self.jsonTable.dataSource = self
        self.jsonTable.delegate = self
        
        parseJSON()
        
    }
    
    func parseJSON() {
        
        let headers: HTTPHeaders = [
            "Content-Type": "application/json",
            "api-key" : "59e59239f557ac905af02a674808dea5",
            "Accept" : "application/json"
        ]
        
        
        Alamofire.request("https://api-sandbox.grnconnect.com/api/v3/destinations", method:.get, parameters: nil, encoding: JSONEncoding.default, headers: headers).responseJSON{ response in
            
            if let JSON1 = response.result.value {
//                print("JSON: \(JSON1)")
   
                let dicResponse = JSON1 as! NSDictionary
//                print("hello",dicResponse)
         
                self.tableArray =  dicResponse.object(forKey: "destinations") as! NSArray
//                print(dictResponceObject,"cshfsbcbcvhbbbc")
                
                for item in self.tableArray { // loop through data items
                    let obj = item as! NSDictionary
   
                    self.destinObj.destinDictionary(dict: obj)
            
                    for (_, _) in obj {
                        //  print("Property: \"\(value as! String)\"")
                    }
                    self.jsonTable.reloadData()
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension ViewController {
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as UITableViewCell
        
        cell.textLabel?.text = (tableArray[indexPath.row] as AnyObject).value(forKey: "name") as? String//self.destinObj.destinName
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.tableArray.count
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(self.tableArray[indexPath.row])
        tableView.deselectRow(at: indexPath, animated: true)
    }

}


